#ifndef __METADATA_NULL_GC_HANDLES_H__
#define __METADATA_NULL_GC_HANDLES_H__

void
null_gc_handles_init (void);

#endif /* __METADATA_NULL_GC_HANDLES_H__ */
